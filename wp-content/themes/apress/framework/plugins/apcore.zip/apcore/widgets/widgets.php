<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
require_once APRESS_EXTENSIONS_PLUGIN_PATH.'widgets/zt_contact_info.php';
require_once APRESS_EXTENSIONS_PLUGIN_PATH.'widgets/zt_recent_posts_by_category.php';
require_once APRESS_EXTENSIONS_PLUGIN_PATH.'widgets/zt_about_me.php';
require_once APRESS_EXTENSIONS_PLUGIN_PATH.'widgets/zt_widget_twitter.php';
require_once APRESS_EXTENSIONS_PLUGIN_PATH.'widgets/zt_recent_portfolios_by_category.php';
require_once APRESS_EXTENSIONS_PLUGIN_PATH.'widgets/zt_custom_menu.php';
